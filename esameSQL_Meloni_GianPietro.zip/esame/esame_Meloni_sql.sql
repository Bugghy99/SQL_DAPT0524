CREATE DATABASE Beverage_Exam2;
USE Beverage_Exam2;

CREATE TABLE category (
    Category_Id INT PRIMARY KEY NOT NULL,
    Description VARCHAR(50) NOT NULL
);

CREATE TABLE product (
    Product_Id INT PRIMARY KEY NOT NULL,
    Category_Id INT NOT NULL,
    Product_Description VARCHAR(50)
);


CREATE TABLE region (
    Region_Id INT PRIMARY KEY NOT NULL,
    Region_Name VARCHAR(50),
    State_Id INT NOT NULL
);
CREATE TABLE state (
    State_Id INT PRIMARY KEY NOT NULL,
    State_Name VARCHAR(50),
    Region_Id INT NOT NULL
);

INSERT INTO category (Category_Id, Description)
VALUES 
(1 , 'Superalcolici'), 
(3 , 'Alcolici'),
(4 , 'Bibite analcoliche');

INSERT INTO product (Product_Id, Category_Id, Product_Description)
VALUES (1 , 1 , 'Grappa dei monti delle vigne'),
(2 , 3 , 'Birra'),
(3 , 4 ,'Cola'),
(4 , 1 , 'Bargnolino'),
(5 , 4 , 'Fanta');


INSERT INTO region (Region_Id, Region_Name, State_Id)
VALUES 
(1 , 'East Asia' , 1),
(2 , 'East Asia' , 2),
(3 , 'East Asia' , 3),
(4 , 'USA' , 4),
(5 , 'USA' , 5),
(6 , 'USA' , 6),
(7 , 'Europe' , 7),
(8 , 'Europe' , 8),
(9 , 'Europe' , 9);

INSERT INTO state (State_Id, State_Name, Region_Id)
VALUES 
(1 , 'Singapore', 1),
(2 , 'Taiwan', 1),
(3 , 'Indonesia', 1),
(4 , 'Texas', 4),
(5 , 'Florida', 5),
(6 , 'Ohio', 6),
(7 , 'Italy', 7),
(8 , 'France', 8),
(9 , 'Slovenia', 9);


CREATE TABLE sales (
    Sale_Id INT PRIMARY KEY NOT NULL,
    Product_Id INT NOT NULL,
    Price INT NOT NULL,
    Quantity INT NOT NULL,
    Region_Id INT NOT NULL,
    State_Id INT NOT NULL,
    Order_Date DATE NOT NULL
);

INSERT INTO sales (Sale_Id, Product_Id, Price, Quantity, Region_Id, State_Id, Order_Date)
VALUES 
(1 , 1 , 25 , 80 , 1 , 2, '2024-10-22'),
(2 , 2 , 5 , 150 , 1 , 1, '2024-10-20'),
(3 , 2 , 5 , 220 , 1 , 3, '2024-09-15'),
(4 , 3 , 3 , 800 , 4 , 4, '2024-09-02'),
(5 , 4 , 40 , 60 , 5 , 5, '2024-08-05'),
(6 , 4 , 40 , 80 , 6 , 6, '2024-07-04'),
(7 , 4 , 25 , 2 , 8, 8, '2024-06-22'),
(8 , 2 , 5 , 300 , 7 , 7, '2024-05-22'),
(9 , 3 , 4 , 30 , 9, 9, '2024-03-04'),
(10 , 1 , 25 , 20 , 7 , 7, '2024-03-02'),
(11 , 1 , 25 , 10 , 8 , 8, '2024-02-22');

/* Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità
 dei valori di ciascuna PK (una query per tabella implementata).*/

SELECT 
    Category_Id, COUNT(*)
FROM
    category
GROUP BY Category_Id
HAVING COUNT(*) > 1;

SELECT Product_Id, COUNT(*)
FROM product
GROUP BY Product_Id
HAVING COUNT(*) > 1;

SELECT Region_Id, COUNT(*)
FROM region
GROUP BY Region_Id
HAVING COUNT(*) > 1;

SELECT Sale_Id, COUNT(*)
FROM sales
GROUP BY Sale_Id
HAVING COUNT(*) > 1;

SELECT State_Id, COUNT(*)
FROM state
GROUP BY State_Id
HAVING COUNT(*) > 1;

ALTER TABLE category
RENAME COLUMN Description TO Cat_Description;

/* Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 
180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False */

SELECT 
    Sale_Id,
    Order_Date,
    Product_Description AS Product,
    Cat_Description AS Category,
    State_Name,
    Region_Name,
    CASE
        WHEN DATEDIFF(CURDATE(), Order_Date) > 180 THEN 'True'
        ELSE 'False'
    END AS MoreThan180Days
FROM
    sales AS s
        INNER JOIN
    product AS p ON s.Product_Id = p.Product_Id
        INNER JOIN
    region AS r ON r.Region_Id = s.Region_Id
        INNER JOIN
    state AS c ON c.State_Id = s.State_Id
        INNER JOIN
    category AS t ON t.Category_Id = p.Category_Id;
    
    /* Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno
 censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
Nel result set devono comparire solo il codice prodotto e il totale venduto.*/

select 
s.Product_Id,
SUM(s.Quantity) AS TOTAL_QUANTITY
from sales as s
where year (s.Order_date) = (       
SELECT MAX(YEAR (Order_date))
FROM sales
)
GROUP BY s.Product_Id
HAVING SUM(s.Quantity) > (
select AVG(TOTAL_QUANTITY)
FROM (
SELECT SUM(s.Quantity) as TOTAL_QUANTITY
FROM sales AS s 
WHERE YEAR (s.Order_Date) = (
SELECT MAX(YEAR(Order_Date))
from sales
)
GROUP BY s.Product_Id
)
as SUBQUERY
);

/*  Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

select 
Product_Id,
YEAR(s.Order_Date) as year,
SUM(s.Quantity * s.Price) AS total_revenue
from sales as s
group by s.Product_Id, YEAR(s.Order_Date)
having SUM(s.Quantity) > 0;

/*Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescent*/
    
SELECT
year(s.Order_Date) as year,
s.State_id,
c.State_Name,
SUM(s.Quantity * s.Price) as Revenue
FROM sales as s
inner join state as c
on s.State_Id = c.State_Id
GROUP BY year, s.State_Id, c.State_Name
ORDER BY year, Revenue DESC;   

/* Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato*/
select 
c.Cat_Description,
SUM(Quantity) AS Total_Quantity_Sold
from sales as s 
INNER JOIN Product as p
on s.Product_Id = p.Product_Id
INNER JOIN Category as c
on p.Category_Id = c.Category_Id
group by Cat_Description
ORDER BY Total_Quantity_Sold desc;
-- La categoria di articoli maggiormente richiesta dal mercato sono le bibite analcoliche 

/* Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti*/
SELECT 
s.Product_Id,
Product_Description
FROM product as p
LEFT JOIN sales as s
on p.Product_Id = s.Product_Id
where s.Product_Id is Null;

SELECT
Product_Id,
Product_Description
FROM product
where Product_Id NOT IN (select distinct Product_Id from sales);

 /*Creare una vista sui prodotti in modo tale da esporre una
 “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria) */
 Create view Product_Catalogue as
 select 
 p.Product_Id as codice_Prodotto,
 Product_Description as Nome_Prodotto,
 Cat_Description as Nome_Categoria
 from product as p
 inner join category as c
 on p.Category_Id = c.Category_Id;
select * from Product_Catalogue;
 /* Creare una vista per le informazioni geografiche */
create view Geographic_Data as
 select
 r.Region_Id as Region_Code,
 r.region_Name as Region_Name,
 s.State_Name as State_Name
 from region as r 
 inner join state as s 
 on r.Region_Id = s.Region_Id;

select * from Geographic_Data;